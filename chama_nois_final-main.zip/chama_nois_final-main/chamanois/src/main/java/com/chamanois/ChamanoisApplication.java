package com.chamanois;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChamanoisApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChamanoisApplication.class, args);
	}

}
