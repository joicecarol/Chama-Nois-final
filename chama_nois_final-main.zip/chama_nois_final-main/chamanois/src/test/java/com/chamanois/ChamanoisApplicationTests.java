package com.chamanois;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChamanoisApplicationTests {

	@Test
	void contextLoads() {
	}

}
